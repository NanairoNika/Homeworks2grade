import urllib.request
import re
req = urllib.request.Request('http://ulanmedia.ru/')

with urllib.request.urlopen(req) as response:
   gazeta = response.read().decode('utf-8')

regPostTitle = re.compile('<span>.*?</span>', flags=re.DOTALL)
titles = regPostTitle.findall(gazeta)

regTag = re.compile('<.*?>', re.DOTALL)
regScript = re.compile('<script>.*?</script>', re.DOTALL)
regComment = re.compile('<!--.*?-->', re.DOTALL)
smth=[]
clean_t = regScript.sub("", gazeta)
clean_t = regComment.sub("", clean_t)
clean_t = regTag.sub("", clean_t)
print (titles)
print(clean_t)
