
import sqlite3

f = open('Glossing_rules.txt','r', encoding = 'utf-8')
text = f.read()
text = text.split()
z = len(text)

con = sqlite3.connect('hittite.db')
cur = con.cursor()
cur.execute('SELECT * FROM wordforms')
words = cur.fetchall()
table1 = 'CREATE TABLE datawf (idwf, Lemma, Wordform, Glosses)'
table2 = 'CREATE TABLE datagl (idgl, mean, trans)'
table3 = 'CREATE TABLE datagen (idwf, idgl)'


n = 1
l = 0
dcgl = []
dcmn = []
while l < z-1:
    dcgl.append(text[l])
    dcmn.append(text[l+1])
    l+=2

for p in words:
    format_str = """INSERT INTO datawf (idwf, Lemma, Wordform, Glosses)
    VALUES ({Null}, "{le}", "{wo}", "{gl}");"""
    sql_command = format_str.format(Null = n, le=p[0], wo=p[1], gl=p[2])
    cur.execute(sql_command)


    format_str2 = """INSERT INTO datagl (idgl, mean)
        VALUES ({Null}, "{me}");"""
    sql_command2 = format_str2.format(Null=n, me=p[2])
    cur.execute(sql_command2)
    n+=1

cur.execute('SELECT * FROM datagl')
scdtbl = cur.fetchall()
cur.execute('SELECT * FROM datawf')
frttbl = cur.fetchall()


for frt in frttbl:
    for scd in scdtbl:
        if frttbl[3] == scdtbl[2]:
            format_str2 = """INSERT INTO datagen (idwf, idgl)
            VALUES ({wf}", "{gl}");"""
            sql_command2 = format_str2.format(wf=frttbl[0], gl=scdtbl[0])
            cur.execute(sql_command2)

for row in cur.execute('SELECT idwf, idgl from datagen ORDER BY idwf, idgl LIMIT 10'):
        print(row)