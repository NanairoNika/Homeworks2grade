import bisect
import random

import pytest
import numpy as np


def quantize_slow(x, n):
    values = sorted(list(x))
    boundaries = [values[len(x) * p // n] for p in range(n)]

    quantized = [bisect.bisect_left(boundaries, x[i]) for i in range(len(x))]
    return np.array(boundaries), np.array(quantized)


x = list(range(10))
print(quantize_slow(x,2))